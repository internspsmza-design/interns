<?php
return [
  'APP_BASE' => '/INTERNS', // change if you use a different folder
  'DB_HOST' => '127.0.0.1',
  'DB_NAME' => 'interns_app',
  'DB_USER' => 'root',
  'DB_PASS' => '',
  'DEBUG'   => true,
];
