<?php echo "ping-ok"; ?>
